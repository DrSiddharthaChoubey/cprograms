#include<stdio.h>

int main()
{
    int i;
    for(i=0;i<256;i++)
    {
        printf("Decimal : %d \t ASCII : %c \n",i,i);
    }
    return 0;
}
