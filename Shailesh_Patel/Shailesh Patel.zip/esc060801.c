#include<stdio.h>

int main()
{
    printf("Testing Escape Sequence Beep \a \n");
    printf("Testing Escape Sequence Backspace\b \n");
    printf("Testing Escape Sequences Carriage Return \rTESTING \n");
    printf("Testing Escape Sequences Backslash \\ \n");
    printf("Testing Escape Sequences \t Horizontal Tab\n");
    printf("Testing Escape Sequences \v Vertical Tab\n");
    return 0;
}
